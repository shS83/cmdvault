# cmdvault Error Modal (turvallinen osakorjaus)

Muutokset pohjautuvat keskustelussa toimitettuihin lähdeversioihin, eivät nykyiseen paikalliseen Git-työpuuhun. **Älä ylikirjoita suoraan** nykyisiä toimivia tiedostoja. Tarkista patchit `git apply --check` ja sovita tarvittaessa käsin.

Pitkät virheilmoitukset piirtyvät pyöristettyyn, vieritettävään modaalin. Nuoli ylös/alas vierittää; Esc/Enter sulkee. Lyhyet ilmoitukset näkyvät normaalisti. API-avaimia tai salaisuuksia ei tule sisällyttää virheilmoituksiin.

Testaus: `python -m py_compile cmdvault src/visuals/picker.py`; `git apply --check picker.patch cmdvault.patch`. Jos jälkimmäinen epäonnistuu, patch on vanhaa versiota vasten ja pitää sovittaa nykyiseen versioon.

Tämä ei toteuta historian varsinaista synkronointia, eikä lähetä dataa palvelimelle.
