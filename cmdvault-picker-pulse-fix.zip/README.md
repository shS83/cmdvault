# cmdvault – Sync Pulse in the actual fzf picker

This patch updates the actual command picker `src/visuals/picker.py` rather than only the separate Kitty graphics diagnostic renderer.

- Reserves **8 bottom terminal rows** in fzf itself (`--margin`), leaving sufficient space for the existing 80 px orb and its 32 px inset, accounting for typical ~16 px cell height. Results continue to scroll under fzf management instead of being hidden.
- Fills the interior of that space using panel background `#0B0812`, while avoiding the outer neon frame cells.
- Uses existing `KittyPulseOverlay` from the previous v3 patch, with distinct Kitty image ID, status text and clean teardown.
- Sends Kitty graphics only after an intact fzf escape sequence, from the parent terminal owner. No new writer thread.
- Uses `READY` as the default state; this patch does **not** claim real history was synchronized and does not add network activity.

## Install

In `~/Code/cmdvault`, after keeping a backup of the existing `picker.py`, copy `src/visuals/picker.py` from this archive to your repo and `tests/test_picker_pulse_margin.py` to your tests. Requires the `KittyPulseOverlay` implementation from the previous v3 package in `src/visuals/kitty.py` and `src/visuals/sync_pulse.py`.

Run:

```bash
PYTHONPATH="$PWD" uv run --extra graphics python -m unittest discover -s tests -p 'test_*pulse*.py' -v
./cmdvault --graphics kitty
./install.sh
cmdvault --graphics kitty
```

The test suite here validates layout and module behavior, not a real interactive Kitty + fzf session. This version does not attempt automatic live status updates from the unfinished history sync engine.
