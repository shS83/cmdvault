# cmdvault Sync Pulse — pixel-size fix

Replace `src/visuals/kitty.py` and `src/visuals/picker.py` in your working tree, then run `./install.sh`.

- The orb image is now 104 × 104 native pixels (metallic sphere ≈ 60 px diameter, aura extends beyond).
- Kitty placement deliberately omits `c=` and `r=`: they caused terminal-cell-dependent scaling.
- Both overlay and label share 64 px right/bottom inset.
- READY text tracks the ball center line rather than `rows - 4`.
- fzf's reserved bottom margin is 5 terminal rows.

The source panel background and current `READY` state are unchanged. The status still does not claim real-history sync is finished.

Test the development copy first with `./cmdvault --graphics kitty`; when satisfied, run `./install.sh` to replace the separately installed copy.
