# Sync Pulse — Kitty integration

Files are arranged as paths relative to the cmdvault repository. `kitty.py`, `renderer.py`, and `compositor.py` are the versions supplied in the conversation; only `kitty.py` was changed. Back up local changes and compare/diff before replacing.

This patch provides a visual orb at the top right of the **Kitty renderer**, status text, and animation updates through the existing `tick()` loop. It does not add HTTP calls or change real sync behavior. Initial state is `READY`, **not `SYNCED`**. The orb uses a different image ID from the frame and is deleted on cleanup/resize.

For the real state, call `renderer.set_sync_state("syncing" | "error" | "offline" | "disabled" | "ready" | "synced")` from the existing application's sync state callback. Do not use `synced` until production history sync has actually completed with no outstanding changes. Rendering of the text label when state changes occurs on the next full `draw()`, while the orb changes on the next `tick()`.

The current `KittyRenderer` implementation reserves its first row, so this patch uses two graphic cells and a status label there. For widths below 24 columns, no overlay is rendered. It does not modify fzf itself or any unseen app entrypoint, and **no Sync Pulse is added to SIXEL/ANSI paths** because those implementations were not supplied. If the current terminal UI redraws independently through fzf, its output may overwrite graphics; test in Kitty.

1. Copy `src/visuals/{sync_pulse,kitty}.py` and `tests/test_sync_pulse.py` into your repository.
2. `uv sync --extra graphics`
3. `PYTHONPATH="$PWD" uv run --extra graphics python -m unittest discover -s tests -p 'test_sync_pulse.py' -v`
4. Exercise `cmdvault --graphics kitty` on a disposable terminal and test resize, quit, and `--no-animation`.

**Important:** This is a source-level integration patch, not a verified end-to-end application integration, because the actual `src/visuals/ansi.py`, `src/visuals/config.py`, app launcher and event loop were not supplied. The animated orb updates only when the host invokes `KittyRenderer.tick()` regularly.
