# Sync Pulse — alaoikean kulman versio

Asenna `src/visuals/kitty.py`, `src/visuals/sync_pulse.py` ja testit cmdvault-projektin vastaaviin hakemistoihin. Muut tiedostot ovat alkuperäisiä eikä niitä tarvitse korvata.

- Pallo on 5 sarakkeen × 3 rivin kuvana **oikeassa alakulmassa**, vähintään useita sarakkeita ja rivejä irti Neon Frame -reunuksesta.
- Viimeiset seitsemän terminaaliriviä varataan orbia varten (kun koko on vähintään 32×14), jolloin renderöijä ei piirrä tulostekstiä sen päälle. Pienillä terminaaleilla orb jätetään pois.
- Pallon bitmap on yhdistetty paneelin taustaväriin `#0b0812`, joten sen takana ei näy erillistä läpikuultavaa laatikkoa.
- Tilan tekstivahvistus sijoitetaan pallon alapuolelle.
- Renderöinti perustuu jo käytössä olevaan `tick()`-päivitykseen. Sync-tilat on edelleen yhdistettävä sovelluksen tapahtumiin.

**Huom:** renderöijä voi rajata omat piirtorivinsä, mutta jos fzf:n varsinaisen listan navigointia/ikkunakokoa halutaan lyhentää vastaavasti, se edellyttää myös picker-komennon (esim. `--height` tai `--margin`) muuttamista. Se ei sisälly tähän muutokseen, koska picker-käynnistimen lähdekoodi ei ollut käytettävissä.

Testaa: `PYTHONPATH="$PWD" uv run --extra graphics python -m unittest discover -s tests -p 'test_*pulse*.py' -v`.
