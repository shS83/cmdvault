"""Check the reserved pulse layout without requiring a live Kitty terminal."""
import pathlib
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]

class KittyPulseLayoutTest(unittest.TestCase):
    def test_orb_uses_bottom_right_reserved_rows(self):
        source = (ROOT / 'src/visuals/kitty.py').read_text()
        self.assertIn('position = (columns - 12, rows - 7)', source)
        self.assertIn('content_end = self.height - 7', source)
        self.assertIn('label_row = self.height - 3', source)
        self.assertIn('p=1,c=5,r=3,z=3', source)

    def test_pulse_image_matches_terminal_background(self):
        source = (ROOT / 'src/visuals/kitty.py').read_text()
        self.assertIn('(11, 8, 18, 255)', source)
        self.assertIn('image.alpha_composite(orb)', source)
