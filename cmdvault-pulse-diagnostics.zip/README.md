# Sync Pulse visibility diagnostic

From the cmdvault project root copy `probe_pulse.py` and run:

```bash
PYTHONPATH="$PWD" uv run --extra graphics python probe_pulse.py
```

The direct probe uses the current `src/visuals/kitty.py` and `src/visuals/sync_pulse.py` and should show the metallic orb in the bottom-right corner while cycling READY, SYNCING, SYNCED and ERROR. It does not use the installed `~/.local/bin/cmdvault`, picker, or Cloud Sync server.

* If the orb **shows** in the probe but not in cmdvault, check installed-vs-source executable and whether KittyRenderer is selected.
* If the orb **does not show** in the probe, investigate Kitty graphics support/protocol (and send output of `echo "$TERM"; echo "$KITTY_WINDOW_ID"`), not fzf result-row truncation.

Check the installed source:

```bash
cd ~/Code/cmdvault
grep -n 'class KittyPulseOverlay' src/visuals/kitty.py
type -a cmdvault
readlink -f ~/.local/bin/cmdvault
./install.sh
```

No real history is uploaded by the probe.
