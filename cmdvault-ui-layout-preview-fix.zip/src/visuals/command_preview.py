"""Safe, read-only full-command fzf preview."""
import json
import sys
from pathlib import Path


def main():
    if len(sys.argv) != 3:
        return 2
    try:
        commands = json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
        index = int(sys.argv[2].split("\t", 1)[0].strip())
        if not isinstance(commands, list) or not 0 <= index < len(commands):
            return 1
        item = commands[index]
        if isinstance(item, str):  # Backward compatible with existing preview files.
            command, hosts = item, []
        elif isinstance(item, dict):
            command, hosts = item.get("command"), item.get("hosts", [])
        else:
            return 1
        if not isinstance(command, str) or not isinstance(hosts, list):
            return 1
        palette = {
            "ALPHATAURI": "0;229;255",
            "EPSILONTAURI": "255;79;216",
            "THETATAURI": "184;255;77",
            "OUROBOROS": "179;136;255",
        }
        labels = []
        for host in dict.fromkeys(hosts):
            if not isinstance(host, str):
                continue
            name = host.upper()
            # Escape terminal control codes from any untrusted hostname metadata.
            if not name or len(name) > 64 or not all(c.isalnum() or c in "-_" for c in name):
                continue
            shade = palette.get(name, "255;194;102")
            labels.append(f"\x1b[38;2;{shade}m[{name}]\x1b[0m")
        if labels:
            print("".join(labels))
            print()
        print(command)
    except (OSError, ValueError, IndexError, TypeError) as exc:
        print(f'Preview unavailable: {exc}', file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
